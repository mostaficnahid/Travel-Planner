---
name: Voyage Intelligence
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#44474d'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#75777e'
  outline-variant: '#c5c6ce'
  surface-tint: '#4e5f7e'
  primary: '#031632'
  on-primary: '#ffffff'
  primary-container: '#1a2b48'
  on-primary-container: '#8293b5'
  inverse-primary: '#b6c7eb'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#161714'
  on-tertiary: '#ffffff'
  tertiary-container: '#2b2b28'
  on-tertiary-container: '#93928e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#b6c7eb'
  on-primary-fixed: '#081b38'
  on-primary-fixed-variant: '#374765'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474744'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
  surface-white: '#FFFFFF'
  success-green: '#10B981'
  warning-amber: '#F59E0B'
  danger-red: '#EF4444'
  indigo-accent: '#6366F1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  section-gap: 80px
---

## Brand & Style
The design system for this product is anchored in the concept of "Travel Intelligence"—a fusion of high-end concierge service and sophisticated data engineering. It avoids the whimsical tropes of typical travel apps in favor of an aesthetic that feels reliable, expert, and effortlessly premium.

The visual direction follows a **Corporate / Modern** movement with a heavy **Minimalist** influence. It prioritizes clarity through generous whitespace and a rigorous hierarchy. The mood is calm and authoritative, utilizing editorial typography to romanticize the destination while maintaining a utilitarian, high-performance SaaS interface for planning and logistics. The interface should feel like a digital leather-bound planner: tactile, organized, and bespoke.

## Colors
The palette is built on a foundation of "Deep Travel Blue," providing a sense of stability and institutional trust. This is contrasted against a "Warm Neutral" background (`#F9F7F2`), which prevents the interface from feeling sterile and mimics the quality of premium stationery.

- **Primary**: Used for core branding, headers, and primary navigation elements.
- **Secondary (Indigo)**: Reserved for high-intent actions, primary CTAs, and active interactive states.
- **Surface**: Pure white is used exclusively for cards and modals to create a distinct "layered" effect over the warm neutral background.
- **Status Colors**: Success, Warning, and Danger colors are slightly desaturated to maintain the sophisticated tone while providing clear functional feedback.

## Typography
The typographic strategy employs a high-contrast pairing. **Playfair Display** is used for editorial moments—headlines, destination names, and hero sections—to evoke the feeling of a luxury travel magazine. 

**Geist** is used for all functional UI elements, data points, and body copy. Its technical, precise nature balances the romanticism of the serif headings. For data-heavy views like budgets or timestamps, use Geist’s tabular figures to ensure perfect alignment. Labels should frequently use uppercase with light letter-spacing to reinforce the professional SaaS aesthetic.

## Layout & Spacing
The layout follows a **Fluid Grid** model with generous padding to prevent information density from feeling overwhelming. 

- **Desktop**: A 12-column grid is used. The "Map-Centric" layout often utilizes a split-screen pattern: a fixed-width 400px side panel for itineraries and data, with a flexible map area filling the remaining viewport.
- **Mobile**: A single-column layout using a "Bottom Sheet" pattern for contextual information. The primary navigation is anchored to the bottom for ease of reach.
- **Spacing Rhythm**: An 8px base unit drives all dimensions. Section gaps are intentionally large (80px+) to maintain a "premium" feel of unhurried space.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**. 

The primary background is the warm neutral. Interactive components and content containers (cards) are elevated using white surfaces and a very soft, diffused shadow (e.g., `box-shadow: 0 4px 20px rgba(26, 43, 72, 0.05)`). 

On the Map interface, elements use slightly higher elevation to appear as if floating above the geospatial data. Translucency (Backdrop Blur) is used sparingly—primarily on navigation bars and floating action buttons—to maintain visibility of the map underneath without sacrificing legibility.

## Shapes
The shape language is "Rounded" but controlled. A 12px-16px radius is the standard for cards and main containers, creating an approachable, modern feel. Smaller components like buttons and input fields follow the `rounded-lg` (16px) or pill-shaped conventions to feel "soft" to the touch, especially on mobile. Images of destinations should always feature rounded corners to match the UI containers.

## Components
- **Buttons**: Primary buttons use the Deep Blue background with White text. Secondary buttons use an Indigo outline or a subtle ghost style. All buttons should have a minimum height of 48px for mobile accessibility.
- **Soft Cards**: The primary container. Always white, 16px corner radius, with a subtle 1px border (`#E5E7EB`) and ambient shadow.
- **Chips**: Used for categories (e.g., "Museum," "Restaurant"). These should have a light Indigo tint background with Deep Blue text.
- **Itinerary Timeline**: A vertical line pattern with icons (emojis allowed here) marking temporal events. Use the Success/Warning/Danger colors for budget or weather indicators within the timeline.
- **Input Fields**: Minimalist style. White background, 1px neutral border that shifts to Indigo on focus. Labels should be small, uppercase, and positioned above the field.
- **AI Copilot Card**: Distinguished by a very subtle gradient border or a faint Indigo glow to signal its "intelligence" compared to static data cards.